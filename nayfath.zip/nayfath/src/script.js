document.addEventListener("DOMContentLoaded", function() {
    // Sehemu ya Nambari (1-100)
    const numbersContainer = document.querySelector(".numbers");
    for (let i = 1; i <= 100; i++) {
        const numberElement = document.createElement("div");
        numberElement.textContent = `${i} - ${getNumberWord(i)}`;
        numbersContainer.appendChild(numberElement);
    }

    // Sehemu ya Wanyama
    const animals = [
        "Lion", "Elephant", "Giraffe", "Zebra", "Monkey", "Kangaroo", "Tiger", "Bear", "Wolf", "Penguin",
        "Dog", "Cat", "Rabbit", "Horse", "Cow", "Pig", "Sheep", "Goat", "Duck", "Chicken", "Eagle",
        "Parrot", "Owl", "Bat", "Snake", "Crocodile", "Alligator", "Koala", "Panda", "Cheetah", "Rhino",
        "Leopard", "Jaguar", "Fox", "Camel", "Donkey", "Mule", "Bison", "Buffalo", "Yak", "Antelope",
        "Squirrel", "Beaver", "Raccoon", "Ferret", "Skunk", "Badger", "Otter", "Walrus", "Seal", "Whale",
        "Shark", "Dolphin", "Octopus", "Squid", "Starfish", "Clownfish", "Turtle", "Lobster", "Crab",
        "Snail", "Slug", "Dragonfly", "Ladybug", "Ant", "Bee", "Butterfly", "Grasshopper", "Moth", "Worm",
        "Caterpillar", "Tick", "Spider", "Fly", "Mosquito", "Cockroach", "Flea", "Louse", "Hornet", "Wasps",
        "Midge", "Dragonfly", "Firefly", "Cicada", "Cricket", "Locust", "Praying Mantis", "Bumblebee", "Hornet"
    ];

    const animalsContainer = document.querySelector(".animals");
    animals.forEach(animal => {
        const animalElement = document.createElement("div");
        animalElement.textContent = animal;
        animalsContainer.appendChild(animalElement);
    });

    // Sehemu ya Rangi
    const colors = [
        "Red", "Green", "Blue", "Yellow", "Orange", "Purple", "Pink", "Brown", "Gray", "Black"
    ];

    const colorsContainer = document.querySelector(".colors");
    colors.forEach(color => {
        const colorElement = document.createElement("div");
        colorElement.textContent = color;
        colorElement.style.backgroundColor = color.toLowerCase();
        colorsContainer.appendChild(colorElement);
    });

    // Maswali ya Hesabu
    const mathQuestionText = document.getElementById("math-question");
    const mathAnswerInput = document.getElementById("math-answer");
    const mathSubmitButton = document.getElementById("submit-math-answer");
    const mathResultText = document.getElementById("math-result");

    let currentMathQuestion = {};
    
    // Fungua swali la hesabu
    mathSubmitButton.addEventListener("click", function() {
        const userAnswer = parseInt(mathAnswerInput.value);
        
        if (userAnswer === currentMathQuestion.answer) {
            mathResultText.textContent = "Sahihi!";
            mathResultText.className = "correct";
        } else {
            mathResultText.textContent = `Hapana, jibu sahihi ni ${currentMathQuestion.answer}`;
            mathResultText.className = "incorrect";
        }

        mathAnswerInput.value = ''; // Futa majibu
        setTimeout(generateMathQuestion, 1000); // Fungua swali jingine baada ya sekunde 1
    });

    // Tengeneza swali la hesabu
    function generateMathQuestion() {
        const operations = ["+", "-", "*", "/"];
        const operation = operations[Math.floor(Math.random() * operations.length)];

        let num1 = Math.floor(Math.random() * 10) + 1;
        let num2 = Math.floor(Math.random() * 10) + 1;
        let question = "";
        let answer = 0;

        switch (operation) {
            case "+":
                question = `${num1} + ${num2}`;
                answer = num1 + num2;
                break;
            case "-":
                question = `${num1} - ${num2}`;
                answer = num1 - num2;
                break;
            case "*":
                question = `${num1} * ${num2}`;
                answer = num1 * num2;
                break;
            case "/":
                question = `${num1} / ${num2}`;
                answer = num1 / num2;
                break;
        }

        currentMathQuestion = { question, answer };
        mathQuestionText.textContent = `Swali: ${question}`;
    }

    // Tengeneza swali la kwanza
    generateMathQuestion();
});

// Kusaidia kutafsiri namba kuwa maneno (1-100)
function getNumberWord(num) {
    const words = [
        "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
        "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen",
        "Twenty", "Twenty-one", "Twenty-two", "Twenty-three", "Twenty-four", "Twenty-five", "Twenty-six", "Twenty-seven", 
        "Twenty-eight", "Twenty-nine", "Thirty", "Thirty-one", "Thirty-two", "Thirty-three", "Thirty-four", "Thirty-five",
        "Thirty-six", "Thirty-seven", "Thirty-eight", "Thirty-nine", "Forty", "Forty-one", "Forty-two", "Forty-three",
        "Forty-four", "Forty-five", "Forty-six", "Forty-seven", "Forty-eight", "Forty-nine", "Fifty", "Fifty-one",
        "Fifty-two", "Fifty-three", "Fifty-four", "Fifty-five", "Fifty-six", "Fifty-seven", "Fifty-eight", "Fifty-nine",
        "Sixty", "Sixty-one", "Sixty-two", "Sixty-three", "Sixty-four", "Sixty-five", "Sixty-six", "Sixty-seven",
        "Sixty-eight", "Sixty-nine", "Seventy", "Seventy-one", "Seventy-two", "Seventy-three", "Seventy-four",
        "Seventy-five", "Seventy-six", "Seventy-seven", "Seventy-eight", "Seventy-nine", "Eighty", "Eighty-one",
        "Eighty-two", "Eighty-three", "Eighty-four", "Eighty-five", "Eighty-six", "Eighty-seven", "Eighty-eight",
        "Eighty-nine", "Ninety", "Ninety-one", "Ninety-two", "Ninety-three", "Ninety-four", "Ninety-five",
        "Ninety-six", "Ninety-seven", "Ninety-eight", "Ninety-nine", "One hundred"
    ];
    return words[num - 1];
}
